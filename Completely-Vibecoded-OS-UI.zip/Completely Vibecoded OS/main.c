#include <stdint.h>
#include <stddef.h>

/* ============================================================================
 * COMPLETELY VIBECODED OS - 64MB RAM Windows 95 GUI Kernel
 * Supports x86 (VESA LFB) and ARM64 (QEMU virt / ramfb)
 * ============================================================================ */

/* --- 1. 64MB PHYSICAL MEMORY MANAGER (PMM) --- */
#define RAM_LIMIT_BYTES  (64 * 1024 * 1024) /* 64MB ceiling */
#define PAGE_SIZE        4096
#define TOTAL_PAGES      (RAM_LIMIT_BYTES / PAGE_SIZE) /* 16,384 pages */
#define BITMAP_SIZE      (TOTAL_PAGES / 8)             /* 2,048 bytes */

static uint8_t pmm_bitmap[BITMAP_SIZE];
static uint32_t used_pages = 1024;

void pmm_init(void) {
    /* Mark first 4MB (1,024 pages) as reserved for Firmware, VRAM, and Kernel */
    for (uint32_t i = 0; i < BITMAP_SIZE; i++) {
        pmm_bitmap[i] = (i < (1024 / 8)) ? 0xFF : 0x00;
    }
    used_pages = 1024;
}

void* pmm_alloc_page(void) {
    for (uint32_t byte = 0; byte < BITMAP_SIZE; byte++) {
        if (pmm_bitmap[byte] != 0xFF) {
            for (uint8_t bit = 0; bit < 8; bit++) {
                if (!(pmm_bitmap[byte] & (1 << bit))) {
                    pmm_bitmap[byte] |= (1 << bit);
                    used_pages++;
                    uintptr_t page_idx = (byte * 8) + bit;
                    return (void*)(page_idx * PAGE_SIZE);
                }
            }
        }
    }
    return NULL; /* Out of 64MB physical memory */
}

void pmm_free_page(void* addr) {
    uintptr_t page_idx = ((uintptr_t)addr) / PAGE_SIZE;
    if (page_idx < TOTAL_PAGES && (pmm_bitmap[page_idx / 8] & (1 << (page_idx % 8)))) {
        pmm_bitmap[page_idx / 8] &= ~(1 << (page_idx % 8));
        used_pages--;
    }
}

/* --- 2. WINDOWS 95 PALETTE & FRAMEBUFFER CONFIGURATION --- */
#define SCREEN_W 640
#define SCREEN_H 480

#define WIN_TEAL       0x00008080
#define WIN_GRAY       0x00C0C0C0
#define WIN_LIGHT_GRAY 0x00DFDFDF
#define WIN_DARK_GRAY  0x00808080
#define WIN_WHITE      0x00FFFFFF
#define WIN_BLACK      0x00000000
#define WIN_NAVY       0x00000080
#define WIN_BLUE       0x000000FF
#define WIN_RED        0x00800000
#define WIN_YELLOW     0x00FFFF00
#define WIN_GREEN      0x00008000
#define WIN_CYAN       0x0000FFFF

#if defined(__aarch64__)
/* Default QEMU virt ramfb / framebuffer base */
static volatile uint32_t* framebuffer = (volatile uint32_t*)0x44000000;
#else
/* Default x86 VESA Linear Framebuffer base */
static volatile uint32_t* framebuffer = (volatile uint32_t*)0xE0000000;
#endif

void set_framebuffer_addr(uintptr_t addr) {
    framebuffer = (volatile uint32_t*)addr;
}

void put_pixel(int x, int y, uint32_t color) {
    if (x >= 0 && x < SCREEN_W && y >= 0 && y < SCREEN_H) {
        framebuffer[y * SCREEN_W + x] = color;
    }
}

void fill_rect(int x, int y, int w, int h, uint32_t color) {
    for (int row = y; row < y + h; row++) {
        for (int col = x; col < x + w; col++) {
            put_pixel(col, row, color);
        }
    }
}

void draw_hline(int x, int y, int len, uint32_t color) {
    fill_rect(x, y, len, 1, color);
}

void draw_vline(int x, int y, int len, uint32_t color) {
    fill_rect(x, y, 1, len, color);
}

/* --- 3. COMPACT 8x8 BITMAP FONT (ASCII 32..126) --- */
static const uint8_t font8x8[95][8] = {
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}, /* space */
    {0x18,0x3C,0x3C,0x18,0x18,0x00,0x18,0x00}, /* ! */
    {0x36,0x36,0x00,0x00,0x00,0x00,0x00,0x00}, /* " */
    {0x36,0x36,0x7F,0x36,0x7F,0x36,0x36,0x00}, /* # */
    {0x0C,0x3E,0x03,0x1E,0x30,0x1F,0x0C,0x00}, /* $ */
    {0x00,0x63,0x33,0x18,0x0C,0x66,0x63,0x00}, /* % */
    {0x1C,0x36,0x1C,0x6E,0x3B,0x33,0x6E,0x00}, /* & */
    {0x06,0x06,0x03,0x00,0x00,0x00,0x00,0x00}, /* ' */
    {0x18,0x0C,0x06,0x06,0x06,0x0C,0x18,0x00}, /* ( */
    {0x06,0x0C,0x18,0x18,0x18,0x0C,0x06,0x00}, /* ) */
    {0x00,0x66,0x3C,0xFF,0x3C,0x66,0x00,0x00}, /* * */
    {0x00,0x0C,0x0C,0x3F,0x0C,0x0C,0x00,0x00}, /* + */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x06}, /* , */
    {0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00}, /* - */
    {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C,0x00}, /* . */
    {0x60,0x30,0x18,0x0C,0x06,0x03,0x01,0x00}, /* / */
    {0x3E,0x63,0x73,0x7B,0x6F,0x67,0x3E,0x00}, /* 0 */
    {0x0C,0x0E,0x0C,0x0C,0x0C,0x0C,0x3F,0x00}, /* 1 */
    {0x1E,0x33,0x30,0x1C,0x06,0x33,0x3F,0x00}, /* 2 */
    {0x1E,0x33,0x30,0x1C,0x30,0x33,0x1E,0x00}, /* 3 */
    {0x38,0x3C,0x36,0x33,0x7F,0x30,0x78,0x00}, /* 4 */
    {0x3F,0x03,0x1F,0x30,0x30,0x33,0x1E,0x00}, /* 5 */
    {0x1C,0x06,0x03,0x1F,0x33,0x33,0x1E,0x00}, /* 6 */
    {0x3F,0x33,0x30,0x18,0x0C,0x0C,0x0C,0x00}, /* 7 */
    {0x1E,0x33,0x33,0x1E,0x33,0x33,0x1E,0x00}, /* 8 */
    {0x1E,0x33,0x33,0x3E,0x30,0x18,0x0E,0x00}, /* 9 */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x00}, /* : */
    {0x00,0x0C,0x0C,0x00,0x00,0x0C,0x0C,0x06}, /* ; */
    {0x18,0x0C,0x06,0x03,0x06,0x0C,0x18,0x00}, /* < */
    {0x00,0x00,0x3F,0x00,0x00,0x3F,0x00,0x00}, /* = */
    {0x06,0x0C,0x18,0x30,0x18,0x0C,0x06,0x00}, /* > */
    {0x1E,0x33,0x30,0x18,0x0C,0x00,0x0C,0x00}, /* ? */
    {0x3E,0x63,0x7B,0x7B,0x7B,0x03,0x1E,0x00}, /* @ */
    {0x0C,0x1E,0x33,0x33,0x3F,0x33,0x33,0x00}, /* A */
    {0x3F,0x66,0x66,0x3E,0x66,0x66,0x3F,0x00}, /* B */
    {0x3C,0x66,0x03,0x03,0x03,0x66,0x3C,0x00}, /* C */
    {0x1F,0x36,0x66,0x66,0x66,0x36,0x1F,0x00}, /* D */
    {0x7F,0x46,0x16,0x1E,0x16,0x46,0x7F,0x00}, /* E */
    {0x7F,0x46,0x16,0x1E,0x16,0x06,0x0F,0x00}, /* F */
    {0x3C,0x66,0x03,0x03,0x73,0x66,0x7C,0x00}, /* G */
    {0x33,0x33,0x33,0x3F,0x33,0x33,0x33,0x00}, /* H */
    {0x1E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* I */
    {0x78,0x30,0x30,0x30,0x33,0x33,0x1E,0x00}, /* J */
    {0x67,0x66,0x36,0x1E,0x36,0x66,0x67,0x00}, /* K */
    {0x0F,0x06,0x06,0x06,0x46,0x66,0x7F,0x00}, /* L */
    {0x63,0x77,0x7F,0x7F,0x6B,0x63,0x63,0x00}, /* M */
    {0x63,0x67,0x6F,0x7B,0x73,0x63,0x63,0x00}, /* N */
    {0x1C,0x36,0x63,0x63,0x63,0x36,0x1C,0x00}, /* O */
    {0x3F,0x66,0x66,0x3E,0x06,0x06,0x0F,0x00}, /* P */
    {0x1E,0x33,0x33,0x33,0x3B,0x1E,0x38,0x00}, /* Q */
    {0x3F,0x66,0x66,0x3E,0x36,0x66,0x67,0x00}, /* R */
    {0x1E,0x33,0x07,0x0E,0x38,0x33,0x1E,0x00}, /* S */
    {0x3F,0x2D,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* T */
    {0x33,0x33,0x33,0x33,0x33,0x33,0x3F,0x00}, /* U */
    {0x33,0x33,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* V */
    {0x63,0x63,0x63,0x6B,0x7F,0x77,0x63,0x00}, /* W */
    {0x63,0x63,0x36,0x1C,0x1C,0x36,0x63,0x00}, /* X */
    {0x33,0x33,0x33,0x1E,0x0C,0x0C,0x1E,0x00}, /* Y */
    {0x7F,0x63,0x31,0x18,0x4C,0x66,0x7F,0x00}, /* Z */
    {0x1E,0x06,0x06,0x06,0x06,0x06,0x1E,0x00}, /* [ */
    {0x03,0x06,0x0C,0x18,0x30,0x60,0x40,0x00}, /* backslash */
    {0x1E,0x18,0x18,0x18,0x18,0x18,0x1E,0x00}, /* ] */
    {0x08,0x1C,0x36,0x63,0x00,0x00,0x00,0x00}, /* ^ */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF}, /* _ */
    {0x0C,0x0C,0x18,0x00,0x00,0x00,0x00,0x00}, /* ` */
    {0x00,0x00,0x1E,0x30,0x3E,0x33,0x6E,0x00}, /* a */
    {0x07,0x06,0x06,0x3E,0x66,0x66,0x3B,0x00}, /* b */
    {0x00,0x00,0x1E,0x33,0x03,0x33,0x1E,0x00}, /* c */
    {0x38,0x30,0x30,0x3e,0x33,0x33,0x6E,0x00}, /* d */
    {0x00,0x00,0x1E,0x33,0x3f,0x03,0x1E,0x00}, /* e */
    {0x1C,0x36,0x06,0x0f,0x06,0x06,0x0F,0x00}, /* f */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x1F}, /* g */
    {0x07,0x06,0x36,0x6E,0x66,0x66,0x67,0x00}, /* h */
    {0x0C,0x00,0x0E,0x0C,0x0C,0x0C,0x1E,0x00}, /* i */
    {0x30,0x00,0x30,0x30,0x30,0x33,0x33,0x1E}, /* j */
    {0x07,0x06,0x66,0x36,0x1E,0x36,0x67,0x00}, /* k */
    {0x0E,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00}, /* l */
    {0x00,0x00,0x33,0x7F,0x7F,0x6B,0x63,0x00}, /* m */
    {0x00,0x00,0x1F,0x33,0x33,0x33,0x33,0x00}, /* n */
    {0x00,0x00,0x1E,0x33,0x33,0x33,0x1E,0x00}, /* o */
    {0x00,0x00,0x3B,0x66,0x66,0x3E,0x06,0x0F}, /* p */
    {0x00,0x00,0x6E,0x33,0x33,0x3E,0x30,0x78}, /* q */
    {0x00,0x00,0x3B,0x6E,0x66,0x06,0x0F,0x00}, /* r */
    {0x00,0x00,0x3E,0x03,0x1E,0x30,0x1F,0x00}, /* s */
    {0x08,0x0C,0x3E,0x0C,0x0C,0x2C,0x18,0x00}, /* t */
    {0x00,0x00,0x33,0x33,0x33,0x33,0x6E,0x00}, /* u */
    {0x00,0x00,0x33,0x33,0x33,0x1E,0x0C,0x00}, /* v */
    {0x00,0x00,0x63,0x6B,0x7F,0x7F,0x36,0x00}, /* w */
    {0x00,0x00,0x63,0x36,0x1C,0x36,0x63,0x00}, /* x */
    {0x00,0x00,0x33,0x33,0x33,0x3E,0x30,0x1F}, /* y */
    {0x00,0x00,0x3F,0x19,0x0C,0x26,0x3F,0x00}, /* z */
    {0x38,0x0C,0x0C,0x07,0x0C,0x0C,0x38,0x00}, /* { */
    {0x18,0x18,0x18,0x00,0x18,0x18,0x18,0x00}, /* | */
    {0x07,0x0C,0x0C,0x38,0x0C,0x0C,0x07,0x00}, /* } */
    {0x6E,0x3B,0x00,0x00,0x00,0x00,0x00,0x00}  /* ~ */
};

void draw_char(int x, int y, char c, uint32_t color) {
    if (c < 32 || c > 126) return;
    const uint8_t* glyph = font8x8[c - 32];
    for (int row = 0; row < 8; row++) {
        uint8_t bits = glyph[row];
        for (int col = 0; col < 8; col++) {
            if (bits & (1 << col)) {
                put_pixel(x + col, y + row, color);
            }
        }
    }
}

void draw_text(int x, int y, const char* str, uint32_t color) {
    int cx = x;
    while (*str) {
        if (*str == '\n') {
            cx = x;
            y += 12;
        } else {
            draw_char(cx, y, *str, color);
            cx += 8;
        }
        str++;
    }
}

void draw_text_bold(int x, int y, const char* str, uint32_t color) {
    draw_text(x, y, str, color);
    draw_text(x + 1, y, str, color);
}

/* --- 4. WINDOWS 95 UI WIDGETS --- */

void draw_bevel_box(int x, int y, int w, int h, int sunken, int fill) {
    uint32_t tl_outer = sunken ? WIN_DARK_GRAY : WIN_WHITE;
    uint32_t tl_inner = sunken ? WIN_BLACK     : WIN_LIGHT_GRAY;
    uint32_t br_outer = sunken ? WIN_WHITE     : WIN_BLACK;
    uint32_t br_inner = sunken ? WIN_LIGHT_GRAY: WIN_DARK_GRAY;

    if (fill) {
        fill_rect(x, y, w, h, WIN_GRAY);
    }
    draw_hline(x, y, w, tl_outer);
    draw_vline(x, y, h, tl_outer);
    draw_hline(x + 1, y + 1, w - 2, tl_inner);
    draw_vline(x + 1, y + 1, h - 2, tl_inner);

    draw_hline(x, y + h - 1, w, br_outer);
    draw_vline(x + w - 1, y, h, br_outer);
    draw_hline(x + 1, y + h - 2, w - 2, br_inner);
    draw_vline(x + w - 2, y + 1, h - 2, br_inner);
}

void draw_button(int x, int y, int w, int h, const char* label, int pressed) {
    draw_bevel_box(x, y, w, h, pressed, 1);
    int len = 0;
    while (label[len]) len++;
    int tx = x + (w - len * 8) / 2 + (pressed ? 1 : 0);
    int ty = y + (h - 8) / 2 + (pressed ? 1 : 0);
    draw_text(tx, ty, label, WIN_BLACK);
}

void draw_windows_logo(int x, int y) {
    fill_rect(x,     y,     5, 5, WIN_RED);
    fill_rect(x + 6, y,     5, 5, WIN_GREEN);
    fill_rect(x,     y + 6, 5, 5, WIN_BLUE);
    fill_rect(x + 6, y + 6, 5, 5, WIN_YELLOW);
}

void draw_desktop_icon(int x, int y, const char* label, uint32_t badge_color) {
    draw_bevel_box(x + 8, y + 2, 28, 22, 0, 1);
    fill_rect(x + 11, y + 5, 22, 15, badge_color);
    fill_rect(x + 17, y + 24, 10, 3, WIN_DARK_GRAY);
    draw_bevel_box(x + 12, y + 27, 20, 4, 0, 1);

    draw_text(x + 1, y + 36, label, WIN_BLACK);
    draw_text(x,     y + 35, label, WIN_WHITE);
}

void draw_window(int x, int y, int w, int h, const char* title, int active) {
    draw_bevel_box(x, y, w, h, 0, 1);

    uint32_t bar_color = active ? WIN_NAVY : WIN_DARK_GRAY;
    fill_rect(x + 3, y + 3, w - 6, 18, bar_color);
    draw_text_bold(x + 7, y + 8, title, WIN_WHITE);

    int bx = x + w - 52;
    draw_bevel_box(bx,      y + 5, 14, 14, 0, 1);
    draw_hline(bx + 3, y + 15, 7, WIN_BLACK);

    draw_bevel_box(bx + 15, y + 5, 14, 14, 0, 1);
    draw_hline(bx + 18, y + 8, 8, WIN_BLACK);
    draw_hline(bx + 18, y + 15, 8, WIN_BLACK);
    draw_vline(bx + 18, y + 8, 8, WIN_BLACK);
    draw_vline(bx + 25, y + 8, 8, WIN_BLACK);

    draw_bevel_box(bx + 32, y + 5, 14, 14, 0, 1);
    for (int i = 0; i < 6; i++) {
        put_pixel(bx + 36 + i, y + 9 + i, WIN_BLACK);
        put_pixel(bx + 41 - i, y + 9 + i, WIN_BLACK);
    }

    draw_text(x + 8, y + 25, "File  Edit  View  Help", WIN_BLACK);
    draw_hline(x + 4, y + 36, w - 8, WIN_DARK_GRAY);

    draw_bevel_box(x + 5, y + 39, w - 10, h - 45, 1, 0);
    fill_rect(x + 7, y + 41, w - 14, h - 49, WIN_WHITE);
}

void draw_start_menu(int open) {
    if (!open) return;
    int mx = 2;
    int my = SCREEN_H - 28 - 170;
    int mw = 165;
    int mh = 170;

    draw_bevel_box(mx, my, mw, mh, 0, 1);

    fill_rect(mx + 3, my + 3, 22, mh - 6, WIN_NAVY);
    draw_text_bold(mx + 10, my + mh - 24, "95", WIN_WHITE);

    const char* items[] = {
        "Programs       >",
        "Documents      >",
        "Settings       >",
        "Find           >",
        "Help",
        "Run...",
        "Shut Down..."
    };

    for (int i = 0; i < 7; i++) {
        int iy = my + 8 + i * 22;
        if (i == 0) {
            fill_rect(mx + 27, iy - 3, mw - 31, 20, WIN_NAVY);
            draw_text(mx + 34, iy + 3, items[i], WIN_WHITE);
        } else {
            if (i == 6) {
                draw_hline(mx + 28, iy - 4, mw - 33, WIN_DARK_GRAY);
                draw_hline(mx + 28, iy - 3, mw - 33, WIN_WHITE);
            }
            draw_text(mx + 34, iy + 3, items[i], WIN_BLACK);
        }
    }
}

void draw_cursor(int x, int y) {
    static const char* arrow[14] = {
        "X.............",
        "XX............",
        "XOX...........",
        "XOOX..........",
        "XOOOX.........",
        "XOOOOX........",
        "XOOOOOX.......",
        "XOOOOOOX......",
        "XOOOOOOOX.....",
        "XOOOOXXXXX....",
        "XOOXOOX.......",
        "XOX.XOOX......",
        "XX...XOOX.....",
        "......XX......"
    };
    for (int r = 0; r < 14; r++) {
        for (int c = 0; c < 14; c++) {
            if (arrow[r][c] == 'X') put_pixel(x + c, y + r, WIN_BLACK);
            else if (arrow[r][c] == 'O') put_pixel(x + c, y + r, WIN_WHITE);
        }
    }
}

/* --- 5. FULL DESKTOP COMPOSITION --- */
void render_desktop(int start_menu_open) {
    fill_rect(0, 0, SCREEN_W, SCREEN_H - 28, WIN_TEAL);

    draw_desktop_icon(16, 16,  "My Computer", WIN_BLUE);
    draw_desktop_icon(16, 78,  "Recycle Bin", WIN_DARK_GRAY);
    draw_desktop_icon(16, 140, "Terminal",    WIN_BLACK);
    draw_desktop_icon(16, 202, "Memory Info", WIN_GREEN);

    draw_window(110, 32, 340, 210, "System Properties - 64MB Mode", 0);
    draw_text(124, 82,  "System:", WIN_BLACK);
    draw_text_bold(134, 96,  "Completely Vibecoded OS 95", WIN_NAVY);
    draw_text(134, 110, "Architecture: ARM64 / x86 Hybrid", WIN_BLACK);
    draw_text(124, 134, "Memory Management:", WIN_BLACK);
    draw_text(134, 148, "Total Physical RAM: 64.0 MB", WIN_BLACK);
    draw_text(134, 162, "Kernel + GUI Foot:   4.6 MB", WIN_GREEN);
    draw_text(134, 176, "Free User Memory:   59.4 MB", WIN_BLACK);
    draw_button(360, 208, 76, 22, "OK", 0);

    draw_window(210, 145, 395, 255, "Welcome to Vibecoded OS", 1);
    draw_windows_logo(226, 198);
    draw_text_bold(244, 199, "Welcome to Vibecoded OS 95", WIN_BLACK);
    draw_hline(224, 216, 365, WIN_DARK_GRAY);

    draw_text(226, 226, "Booted in strict 64MB RAM budget.", WIN_BLACK);
    draw_text(226, 240, "All Windows 95 UI primitives active.", WIN_BLACK);

    draw_bevel_box(226, 260, 360, 88, 1, 0);
    fill_rect(228, 262, 356, 84, WIN_BLACK);
    draw_text(234, 268, "C:\\> mem /c", WIN_GRAY);
    draw_text(234, 282, "PMM Bitmap: 16,384 pages (64 MB)", WIN_GREEN);
    draw_text(234, 296, "Framebuffer: 640x480x32bpp OK", WIN_CYAN);
    draw_text(234, 310, "GUI Shell:   Explorer95 Ready", WIN_WHITE);
    draw_text(234, 326, "C:\\> _", WIN_WHITE);

    draw_button(420, 362, 78, 24, "Run...", 0);
    draw_button(506, 362, 78, 24, "Close", 0);

    draw_bevel_box(0, SCREEN_H - 28, SCREEN_W, 28, 0, 1);

    draw_bevel_box(3, SCREEN_H - 25, 62, 22, start_menu_open, 1);
    draw_windows_logo(8, SCREEN_H - 19);
    draw_text_bold(23, SCREEN_H - 18, "Start", WIN_BLACK);

    draw_bevel_box(70, SCREEN_H - 25, 135, 22, 0, 1);
    draw_text(76, SCREEN_H - 18, "System Props", WIN_BLACK);

    draw_bevel_box(208, SCREEN_H - 25, 145, 22, 1, 1);
    draw_text_bold(214, SCREEN_H - 18, "Welcome...", WIN_BLACK);

    draw_bevel_box(SCREEN_W - 72, SCREEN_H - 25, 69, 22, 1, 1);
    draw_text(SCREEN_W - 62, SCREEN_H - 18, "7:54 PM", WIN_BLACK);

    draw_start_menu(start_menu_open);
    draw_cursor(312, 232);
}

void kernel_main(void) {
    pmm_init();

    void* test_page = pmm_alloc_page();
    if (test_page != NULL) {
        pmm_free_page(test_page);
    }

    render_desktop(1);

    while (1) {
#if defined(__aarch64__)
        __asm__ volatile("wfi");
#else
        __asm__ volatile("hlt");
#endif
    }
}
