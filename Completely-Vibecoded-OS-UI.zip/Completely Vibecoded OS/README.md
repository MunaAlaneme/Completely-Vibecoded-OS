# Completely Vibecoded OS (Windows 95 UI Edition)

A bare-metal 64MB RAM operating system kernel with a complete 640x480 Windows 95 graphical user interface, 8x8 bitmap font renderer, desktop icons, multi-window compositor, Start menu, and taskbar.
